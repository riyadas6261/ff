// Firebase Imports
import { initializeApp, FirebaseApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getDatabase, ref, get, set, update, push, query, orderByChild, equalTo, onValue, off, remove, serverTimestamp, Database } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged, createUserWithEmailAndPassword, Auth, User } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";

/**
 * Main admin application class to encapsulate all functionality.
 */
class AdminApp {
    constructor(config) {
        this.firebaseConfig = config;
        /** @type {FirebaseApp|null} */
        this.app = null;
        /** @type {Database|null} */
        this.db = null;
        /** @type {Auth|null} */
        this.auth = null;

        this.state = {
            /** @type {User|null} */
            currentAdminUser: null,
            isAdminSetupComplete: false,
            designatedAdminUid: null,
            appSettings: {},
            gameDataCache: {},
            userDataCache: {},
            fullUserDataCache: {},
            dbListeners: {},
            currentWithdrawalAction: { id: null, type: null, userId: null },
            currentEditingItemId: null,
        };
        
        this.elements = this.cacheDOMElements();
        this.bootstrapInstances = {};
    }

    cacheDOMElements() {
        const getElement = (id) => document.getElementById(id);
        const querySel = (selector) => document.querySelector(selector);
        const querySelAll = (selector) => document.querySelectorAll(selector);
        return {
             adminLoader: getElement('adminLoader'),
             authContainer: getElement('auth-container'),
             loginSection: getElement('admin-login-section'),
             setupSection: getElement('admin-setup-section'),
             mainArea: getElement('admin-main-area'),
             adminLoginForm: getElement('adminLoginForm'),
             adminEmailInput: getElement('adminEmail'),
             adminPasswordInput: getElement('adminPassword'),
             adminLoginStatus: getElement('adminLoginStatus'),
             adminSetupForm: getElement('adminSetupForm'),
             setupEmailInput: getElement('setupEmail'),
             setupPasswordInput: getElement('setupPassword'),
             setupStatus: getElement('adminSetupStatus'),
             adminUserEmailDisplay: getElement('adminUserEmailShort'),
             adminLogoutBtn: getElement('adminLogoutBtnHeader'),
             sidebar: getElement('adminSidebar'),
             sidebarLinks: querySelAll('#adminSidebar .nav-link'),
             sections: querySelAll('#adminMainContent .section'),
             adminPageTitle: getElement('adminPageTitle'),
             adminHeaderLogo: getElement('adminHeaderLogo'),
             dashboardSection: getElement('dashboard-section'),
             statTotalUsers: getElement('statTotalUsers'),
             statActiveTournaments: getElement('statActiveTournaments'),
             statPendingWithdrawals: getElement('statPendingWithdrawals'),
             statCompletedWithdrawals: getElement('statCompletedWithdrawals'),
             statRejectedWithdrawals: getElement('statRejectedWithdrawals'),
             statTotalGames: getElement('statTotalGames'),
             statTotalPromotions: getElement('statTotalPromotions'),
             statFinishedTournaments: getElement('statFinishedTournaments'),
             dashboardStatus: getElement('dashboardStatus'),
             pendingWithdrawalCountBadge: getElement('pendingWithdrawalCountBadge'),
             gamesTableBody: getElement('gamesTableBody'),
             gameModalEl: getElement('gameModal'),
             gameModalTitle: getElement('gameModalTitle'),
             gameForm: getElement('gameForm'),
             gameEditId: getElement('gameEditId'),
             gameNameInput: getElement('gameName'),
             gameImageFileInput: getElement('gameImageFile'),
             gameImageUrlInput: getElement('gameImageUrl'),
             saveGameBtn: getElement('saveGameBtn'),
             gameStatus: getElement('gameStatus'),
             gamesStatus: getElement('gamesStatus'),
             addNewGameBtn: getElement('addNewGameBtn'),
             promotionsTableBody: getElement('promotionsTableBody'),
             promotionModalEl: getElement('promotionModal'),
             promotionModalTitle: getElement('promotionModalTitle'),
             promotionForm: getElement('promotionForm'),
             promotionEditId: getElement('promotionEditId'),
             promoImageFileInput: getElement('promoImageFile'),
             promoImageUrlInput: getElement('promoImageUrl'),
             promoLinkInput: getElement('promoLink'),
             savePromotionBtn: getElement('savePromotionBtn'),
             promotionStatus: getElement('promotionStatus'),
             promotionsStatus: getElement('promotionsStatus'),
             addNewPromotionBtn: getElement('addNewPromotionBtn'),
             tournamentsTableBody: getElement('tournamentsTableBody'),
             addTournamentModalEl: getElement('addTournamentModal'),
             tournamentForm: getElement('tournamentForm'),
             tournamentModalTitle: getElement('tournamentModalTitle'),
             tournamentEditId: getElement('tournamentEditId'),
             tournamentGameSelect: getElement('tournamentGame'),
             tournamentNameInput: getElement('tournamentName'),
             tournamentStartTimeInput: getElement('tournamentStartTime'),
             tournamentStatusSelect: getElement('tournamentStatus'),
             tournamentEntryFeeInput: getElement('tournamentEntryFee'),
             tournamentPrizePoolInput: getElement('tournamentPrizePool'),
             tournamentPerKillInput: getElement('tournamentPerKill'),
             tournamentMaxPlayersInput: getElement('tournamentMaxPlayers'),
             tournamentTagsInput: getElement('tournamentTags'),
             tournamentDescriptionInput: getElement('tournamentDescription'),
             tournamentRoomIdInput: getElement('tournamentRoomId'),
             tournamentRoomPasswordInput: getElement('tournamentRoomPassword'),
             tournamentShowIdPassCheckbox: getElement('tournamentShowIdPass'),
             saveTournamentBtn: getElement('saveTournamentBtn'),
             addNewTournamentBtn: getElement('addNewTournamentBtn'),
             addTournamentStatus: getElement('addTournamentStatus'),
             tournamentsStatus: getElement('tournamentsStatus'),
             usersSection: getElement('users-section'),
             usersTableBody: getElement('usersTableBody'),
             userSearchInput: getElement('userSearchInput'),
             userModalEl: getElement('userModal'),
             userModalTitle: getElement('userModalTitle'),
             userDetailUid: getElement('userDetailUid'),
             userDetailEmail: getElement('userDetailEmail'),
             userDetailName: getElement('userDetailName'),
             userDetailCreatedAt: getElement('userDetailCreatedAt'),
             userDetailBalance: getElement('userDetailBalance'),
             userDetailWinning: getElement('userDetailWinning'),
             userDetailBonus: getElement('userDetailBonus'),
             userDetailReferralCode: getElement('userDetailReferralCode'),
             userDetailReferredBy: getElement('userDetailReferredBy'),
             userDetailReferredCount: getElement('userDetailReferredCount'),
             userDetailStatus: getElement('userDetailStatus'),
             updateBalanceForm: getElement('updateBalanceForm'),
             editUserUid: getElement('editUserUid'),
             balanceUpdateAmountInput: getElement('balanceUpdateAmount'),
             balanceUpdateTypeSelect: getElement('balanceUpdateType'),
             balanceUpdateReasonInput: getElement('balanceUpdateReason'),
             balanceUpdateStatus: getElement('balanceUpdateStatus'),
             userBlockBtn: getElement('userBlockBtn'),
             userDeleteBtn: getElement('userDeleteBtn'),
             addUserModalEl: getElement('addUserModal'),
             addUserForm: getElement('addUserForm'),
             newUserNameInput: getElement('newUserName'),
             newUserEmailInput: getElement('newUserEmail'),
             newUserPasswordInput: getElement('newUserPassword'),
             newUserInitialBalanceInput: getElement('newUserInitialBalance'),
             saveNewUserBtn: getElement('saveNewUserBtn'),
             addUserStatus: getElement('addUserStatus'),
             usersStatus: getElement('usersStatus'),
             pendingWithdrawalsTableBody: getElement('pendingWithdrawalsTableBody'),
             completedWithdrawalsTableBody: getElement('completedWithdrawalsTableBody'),
             rejectedWithdrawalsTableBody: getElement('rejectedWithdrawalsTableBody'),
             withdrawalActionModalEl: getElement('withdrawalActionModal'),
             withdrawalDetailId: getElement('withdrawalDetailId'),
             withdrawalDetailUser: getElement('withdrawalDetailUser'),
             withdrawalDetailUserUid: getElement('withdrawalDetailUserUid'),
             withdrawalDetailAmount: getElement('withdrawalDetailAmount'),
             withdrawalDetailMethod: getElement('withdrawalDetailMethod'),
             withdrawalRejectReasonDiv: getElement('withdrawalRejectReasonDiv'),
             withdrawalRejectReasonInput: getElement('withdrawalRejectReason'),
             withdrawalApproveNoteDiv: getElement('withdrawalApproveNoteDiv'),
             withdrawalApproveNoteInput: getElement('withdrawalApproveNote'),
             withdrawalActionStatus: getElement('withdrawalActionStatus'),
             rejectWithdrawalBtn: getElement('rejectWithdrawalBtn'),
             approveWithdrawalBtn: getElement('approveWithdrawalBtn'),
             withdrawalsStatus: getElement('withdrawalsStatus'),
             registeredPlayersModalEl: getElement('registeredPlayersModal'),
             registeredPlayersModalTitle: getElement('registeredPlayersModalTitle'),
             registeredPlayersTournamentName: getElement('registeredPlayersTournamentName'),
             registeredPlayersTableBody: getElement('registeredPlayersTableBody'),
             registeredPlayersStatus: getElement('registeredPlayersStatus'),
             settingsSection: getElement('settings-section'),
             appSettingsForm: getElement('appSettingsForm'),
             settingLogoUrlInput: getElement('settingLogoUrl'),
             settingAppNameInput: getElement('settingAppName'),
             settingMinWithdrawInput: getElement('settingMinWithdraw'),
             settingMinDepositInput: getElement('settingMinDeposit'),
             settingReferralBonusInput: getElement('settingReferralBonus'),
             settingSupportContactInput: getElement('settingSupportContact'),
             settingCashfreeAppIdInput: getElement('settingCashfreeAppId'),
             settingCashfreeModeSelect: getElement('settingCashfreeMode'),
             settingImgbbApiKeyInput: getElement('settingImgbbApiKey'),
             settingPolicyPrivacyInput: getElement('settingPolicyPrivacy'),
             settingPolicyTermsInput: getElement('settingPolicyTerms'),
             settingPolicyRefundInput: getElement('settingPolicyRefund'),
             settingPolicyFairPlayInput: getElement('settingPolicyFairPlay'),
             settingsStatus: getElement('settingsStatus'),
             addDemoDataBtn: getElement('addDemoDataBtn'),
             transactionsSection: getElement('transactions-section')
        };
    }

    init() {
        try {
            this.app = initializeApp(this.firebaseConfig);
            this.db = getDatabase(this.app);
            this.auth = getAuth(this.app);
            console.log("Admin Panel: Firebase Initialized.");
        } catch (error) {
            console.error("Admin Panel: Firebase initialization failed:", error);
            document.body.innerHTML = `<div class="alert alert-danger m-5"><strong>Critical Error:</strong> Could not connect. Check console and config.</div>`;
            return;
        }
        this.initializeEventListeners();
        onAuthStateChanged(this.auth, this.handleAdminAuthStateChange.bind(this));
    }

    // --- UTILITY FUNCTIONS ---

    showLoader(show) { if (this.elements.adminLoader) this.elements.adminLoader.style.display = show ? 'flex' : 'none'; }
    showStatus(element, message, type = 'danger', autohide = 5000) { if (!element) return; element.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`; if (autohide) setTimeout(() => { const alert = element.querySelector('.alert'); if (alert) this.getBootstrapInstance(alert, 'Alert')?.close(); }, autohide); }
    clearStatus(element) { if (element) element.innerHTML = ''; }
    formatDate(timestamp) { if (!timestamp) return 'N/A'; return new Date(timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }); }
    formatCurrency(amount) { const num = Number(amount); return isNaN(num) ? '₹--' : `₹${num.toFixed(2)}`; }
    getBootstrapInstance(element, componentType = 'Modal') { if (!element) return null; const key = `${componentType}-${element.id}`; if (!this.bootstrapInstances[key]) this.bootstrapInstances[key] = new window.bootstrap[componentType](element); return this.bootstrapInstances[key]; }
    
    // --- AUTH & SETUP ---

    async handleAdminAuthStateChange(user) {
        console.log("Admin Auth State Changed. User:", user ? user.uid : 'null');
        this.showLoader(true);
        this.detachAllAdminListeners();
        this.state.currentAdminUser = user;

        if (user) {
            if (!this.state.designatedAdminUid) await this.checkAdminSetup();
            if (this.isDesignatedAdmin(user)) {
                this.elements.adminUserEmailDisplay.textContent = user.email;
                this.elements.authContainer.style.display = 'none';
                this.elements.mainArea.style.display = 'block';
                await this.loadSettings();
                this.showAdminSection('dashboard-section');
                this.setupRealtimeAdminListeners();
            } else {
                alert(`Access Denied. ${user.email} is not the designated admin.`);
                await this.logoutAdminUser();
            }
        } else {
            this.state.currentAdminUser = null;
            this.state.designatedAdminUid = null;
            this.state.isAdminSetupComplete = false;
            this.elements.mainArea.style.display = 'none';
            this.elements.authContainer.style.display = 'block';
            await this.handleInitialLoad();
        }
        this.showLoader(false);
    }
    
    // ... other methods like checkAdminSetup, setupAdmin, loginAdmin, logoutAdminUser, etc.

    // --- DATA LOADING & RENDERING ---
    
    showAdminSection(sectionId) {
        this.elements.sections.forEach(sec => sec.classList.remove('active'));
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            const link = this.elements.sidebarLinks.find(l => l.dataset.section === sectionId);
            this.elements.adminPageTitle.textContent = link?.textContent.trim().replace(/\s\d+$/, '') || 'Dashboard';
            this.elements.sidebarLinks.forEach(l => l.classList.toggle('active', l.dataset.section === sectionId));
            this.loadDataForSection(sectionId);
            this.getBootstrapInstance(this.elements.sidebar, 'Offcanvas')?.hide();
        }
    }

    loadDataForSection(sectionId) {
        if (!this.isDesignatedAdmin(this.state.currentAdminUser)) return;
        switch(sectionId) {
            case 'dashboard-section': this.loadDashboardStats(); break;
            case 'games-section': this.loadGames(); break;
            case 'promotions-section': this.loadPromotions(); break;
            case 'tournaments-section': this.loadTournaments(); break;
            case 'users-section': this.loadUsers(); break;
            case 'withdrawals-section': this.loadWithdrawals('pending'); this.loadWithdrawals('completed'); this.loadWithdrawals('rejected'); break;
            case 'settings-section': this.loadSettings(); break;
        }
    }

    // --- IMAGE UPLOAD (SECURE) ---

    /**
     * Uploads an image file to ImgBB using the API key from settings.
     * @param {File} file The image file to upload.
     * @param {HTMLElement} statusElement The element to display upload status.
     * @returns {Promise<string>} The URL of the uploaded image.
     */
    async uploadToImgBB(file, statusElement) {
        const apiKey = this.state.appSettings.imgbbApiKey;
        if (!apiKey) {
            throw new Error("ImgBB API Key is not configured in App Settings. Please set it first.");
        }
        if (!file) throw new Error("File not selected.");

        const formData = new FormData();
        formData.append('image', file);
        if (statusElement) {
            statusElement.textContent = 'Uploading...';
            statusElement.style.color = 'var(--text-secondary)';
            statusElement.style.display = 'block';
        }

        try {
            const response = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, { method: 'POST', body: formData });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`ImgBB upload failed: ${errorData?.error?.message || response.statusText}`);
            }
            const data = await response.json();
            if (data.success) {
                if (statusElement) statusElement.textContent = 'Upload complete!';
                return data.data.url;
            } else {
                throw new Error(`ImgBB returned an error: ${data.error?.message || 'Unknown error'}`);
            }
        } catch (error) {
            if (statusElement) {
                statusElement.textContent = `Upload Error: ${error.message}`;
                statusElement.style.color = 'var(--danger-color)';
            }
            throw error;
        }
    }
    
    // --- SETTINGS (with ImgBB key) ---

    async loadSettings() {
        if (!this.db) return;
        this.elements.appSettingsForm?.querySelectorAll('input, textarea, button').forEach(el => el.disabled = true);
        try {
            const snapshot = await get(ref(this.db, 'settings'));
            if (snapshot.exists()) {
                this.state.appSettings = snapshot.val() || {};
                const s = this.state.appSettings;
                this.elements.settingLogoUrlInput.value = s.logoUrl || '';
                this.elements.settingAppNameInput.value = s.appName || '';
                this.elements.settingMinWithdrawInput.value = s.minWithdraw || 50;
                this.elements.settingMinDepositInput.value = s.minDeposit || 10;
                this.elements.settingReferralBonusInput.value = s.referralBonus || 5;
                this.elements.settingSupportContactInput.value = s.supportContact || '';
                this.elements.settingCashfreeAppIdInput.value = s.cashfreeAppId || '';
                this.elements.settingCashfreeModeSelect.value = s.cashfreeMode || 'sandbox';
                this.elements.settingImgbbApiKeyInput.value = s.imgbbApiKey || ''; // Load ImgBB key
                this.elements.settingPolicyPrivacyInput.value = s.policyPrivacy || '';
                this.elements.settingPolicyTermsInput.value = s.policyTerms || '';
                this.elements.settingPolicyRefundInput.value = s.policyRefund || '';
                this.elements.settingPolicyFairPlayInput.value = s.policyFairPlay || '';
            }
        } catch (error) {
            this.showStatus(this.elements.settingsStatus, `Error loading settings: ${error.message}`, "danger");
        } finally {
            this.elements.appSettingsForm?.querySelectorAll('input, textarea, button').forEach(el => el.disabled = false);
        }
    }

    async saveSettings(event) {
        event.preventDefault();
        const statusEl = this.elements.settingsStatus;
        this.clearStatus(statusEl);
        const settingsData = {
            logoUrl: this.elements.settingLogoUrlInput.value.trim(),
            appName: this.elements.settingAppNameInput.value.trim(),
            minWithdraw: parseFloat(this.elements.settingMinWithdrawInput.value) || 50,
            minDeposit: parseFloat(this.elements.settingMinDepositInput.value) || 10,
            referralBonus: parseFloat(this.elements.settingReferralBonusInput.value) || 5,
            supportContact: this.elements.settingSupportContactInput.value.trim(),
            cashfreeAppId: this.elements.settingCashfreeAppIdInput.value.trim(),
            cashfreeMode: this.elements.settingCashfreeModeSelect.value,
            imgbbApiKey: this.elements.settingImgbbApiKeyInput.value.trim(), // Save ImgBB key
            policyPrivacy: this.elements.settingPolicyPrivacyInput.value.trim(),
            policyTerms: this.elements.settingPolicyTermsInput.value.trim(),
            policyRefund: this.elements.settingPolicyRefundInput.value.trim(),
            policyFairPlay: this.elements.settingPolicyFairPlayInput.value.trim(),
            lastUpdated: serverTimestamp()
        };
        this.showLoader(true);
        try {
            await set(ref(this.db, 'settings'), settingsData);
            this.state.appSettings = settingsData;
            this.showStatus(statusEl, "Settings saved!", "success");
        } catch (error) {
            this.showStatus(statusEl, `Error saving settings: ${error.message}`, "danger");
        } finally {
            this.showLoader(false);
        }
    }
    
    // All other methods (saveGame, deleteGame, loadUsers, etc.) would be here,
    // refactored to be part of the class and use this.state, this.elements, etc.
}

// --- App Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    const firebaseConfig = {
        apiKey: "AIzaSyArhZxasNGl_aWqscp7J79741pyMMU-8qI",
        authDomain: "ff-tornament-569a0.firebaseapp.com",
        databaseURL: "https://ff-tornament-569a0-default-rtdb.firebaseio.com",
        projectId: "ff-tornament-569a0",
        storageBucket: "ff-tornament-569a0.firebasestorage.app",
        messagingSenderId: "439955201751",
        appId: "1:439955201751:web:640cc110203a6fc39b5a92",
        measurementId: "G-22YH4TG0WX"
    };

    const adminApp = new AdminApp(firebaseConfig);
    adminApp.init();

    // Make instance available for debugging
    window.AdminApp = adminApp;
});
