// Firebase Imports
import { initializeApp, FirebaseApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getDatabase, ref, get, set, update, push, query, orderByChild, equalTo, onValue, runTransaction, off, limitToLast, serverTimestamp, Database } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js";
import { getAuth, signOut, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, Auth, User } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import Swiper from 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.mjs';

// --- TYPE DEFINITIONS ---
// While not strictly enforced without a TypeScript compiler, using JSDoc types improves intellisense and readability.
/** @typedef {import('https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js').FirebaseApp} FirebaseApp */
/** @typedef {import('https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js').Database} Database */
/** @typedef {import('https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js').Auth} Auth */
/** @typedef {import('https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js').User} User */

/**
 * @typedef {Object} UserProfile
 * @property {string} uid
 * @property {string} displayName
 * @property {string} email
 * @property {string|null} photoURL
 * @property {number} balance
 * @property {number} winningCash
 * @property {number} bonusCash
 * @property {number} totalMatches
 * @property {number} wonMatches
 * @property {number} totalEarnings
 * @property {number} referralEarnings
 * @property {number} createdAt
 * @property {string} referralCode
 * @property {Object.<string, boolean>} [joinedTournaments]
 * @property {boolean} isAdmin
 * @property {string} [referredBy]
 */

/**
 * @typedef {Object} AppSettings
 * @property {string} [logoUrl]
 * @property {string} [appName]
 * @property {number} [minWithdraw]
 * @property {number} [minDeposit]
 * @property {number} [referralBonus]
 * @property {string} [referralDescription]
 * @property {number} [newUserBalance]
 * @property {number} [newUserBonus]
 * @property {string} [supportContact]
 * @property {string} [policyPrivacy]
 * @property {string} [policyTerms]
 * @property {string} [policyRefund]
 * @property {string} [policyFairPlay]
 * @property {string} [cashfreeAppId]
 * @property {'sandbox'|'production'} [cashfreeMode]
 * @property {Object.<string, {name: string}>} [games]
 */


// ===============================================================
// ================= !!! IMPORTANT !!! ===========================
// This Firebase project configuration is provided for functionality.
// For production environments, it's recommended to manage these
// keys securely, for example, using environment variables.
// ===============================================================
const firebaseConfig = {
    apiKey: "AIzaSyArhZxasNGl_aWqscp7J79741pyMMU-8qI",
    authDomain: "ff-tornament-569a0.firebaseapp.com",
    databaseURL: "https://ff-tornament-569a0-default-rtdb.firebaseio.com",
    projectId: "ff-tornament-569a0",
    storageBucket: "ff-tornament-569a0.firebasestorage.app",
    messagingSenderId: "439955201751",
    appId: "1:439955201751:web:640cc110203a6fc39b5a92",
    measurementId: "G-22YH4TG0WX"
};
// ===============================================================

/**
 * Main application class to encapsulate all functionality.
 * This approach avoids global variables and organizes code into a professional structure.
 */
class TournamentApp {
    // FIX: Declare class properties with JSDoc to satisfy type checkers.
    /** @type {FirebaseApp|null} */
    app;
    /** @type {Database|null} */
    db;
    /** @type {Auth|null} */
    auth;
    /** @type {object} */
    firebaseConfig;
    /** @type {any} */
    state;
    /** @type {any} */
    elements;
    /** @type {any} */
    bootstrapInstances;

    /**
     * @param {object} config Firebase configuration object.
     */
    constructor(config) {
        /** @type {FirebaseApp|null} */
        this.app = null;
        /** @type {Database|null} */
        this.db = null;
        /** @type {Auth|null} */
        this.auth = null;
        this.firebaseConfig = config;

        /** Application state */
        this.state = {
            /** @type {User|null} */
            currentUser: null,
            /** @type {UserProfile|{}} */
            userProfile: {},
            /** @type {AppSettings|{}} */
            appSettings: {},
            currentSectionId: 'login-section',
            currentTournamentGameId: null,
            validReferrerUid: null,
            dbListeners: {},
            /** @type {Swiper|null} */
            swiperInstance: null,
            /** @type {any} */
            cashfree: null,
        };

        this.elements = this.cacheDOMElements();
        this.bootstrapInstances = {};
    }

    /**
     * Caches all necessary DOM elements for quick access.
     */
    cacheDOMElements() {
        const getElement = (id) => document.getElementById(id);
        const querySel = (selector) => document.querySelector(selector);
        const querySelAll = (selector) => document.querySelectorAll(selector);
        return {
             sections: querySelAll('.section'), bottomNavItems: querySelAll('.bottom-nav .nav-item'), globalLoader: getElement('globalLoaderEl'),
             headerBackBtn: getElement('headerBackBtnEl'), headerTitleContainer: getElement('headerTitleContainerEl'), headerGameTitle: getElement('headerGameTitleEl'), headerWalletChip: getElement('headerWalletChipEl'), headerChipBalance: getElement('headerChipBalanceEl'), headerUserGreeting: getElement('headerUserGreetingEl'), appLogo: getElement('appLogoEl'), notificationBtn: getElement('notificationBtnEl'), notificationBadge: querySel('.notification-badge'),
             loginSection: getElement('login-section'),
             emailLoginForm: getElement('emailLoginForm'),
             loginEmailInput: getElement('loginEmailInputEl'),
             loginPasswordInput: getElement('loginPasswordInputEl'),
             loginEmailBtn: getElement('loginEmailBtnEl'),
             showSignupToggleBtn: getElement('showSignupToggleBtnEl'),
             loginStatusMessage: getElement('loginStatusMessageEl'),
             forgotPasswordLink: getElement('forgotPasswordLinkEl'),
             emailSignupForm: getElement('emailSignupForm'),
             signupEmailInput: getElement('signupEmailInputEl'),
             signupPasswordInput: getElement('signupPasswordInputEl'),
             signupConfirmPasswordInput: getElement('signupConfirmPasswordInputEl'),
             signupReferralCodeInput: getElement('signupReferralCodeInputEl'),
             signupEmailBtn: getElement('signupEmailBtnEl'),
             showLoginToggleBtn: getElement('showLoginToggleBtnEl'),
             signupStatusMessage: getElement('signupStatusMessageEl'),
             homeSection: getElement('home-section'), promotionSlider: getElement('promotionSliderEl'), gamesList: getElement('gamesListEl'), myContestsList: getElement('myContestsListEl'), noContestsMessage: getElement('noContestsMessageEl'),
             tournamentsSection: getElement('tournaments-section'), tournamentsListContainer: getElement('tournamentsListContainerEl'), noTournamentsMessage: getElement('noTournamentsMessageEl'), tournamentTabs: querySelAll('.tournament-tabs .tab-item'),
             walletSection: getElement('wallet-section'), walletTotalBalance: getElement('walletTotalBalanceEl'), walletWinningCash: getElement('walletWinningCashEl'), walletBonusCash: getElement('walletBonusCashEl'), allTransactionsBtn: getElement('allTransactionsBtnEl'), withdrawBtn: getElement('withdrawBtnEl'), addAmountWalletBtn: getElement('addAmountWalletBtnEl'), recentTransactionsList: getElement('recentTransactionsListEl'), noTransactionsMessage: getElement('noTransactionsMessageEl'),
             earningsSection: getElement('earnings-section'), earningsTotal: getElement('earningsTotalEl'), earningsReferral: getElement('earningsReferralEl'), viewEarningsHistoryBtn: getElement('viewEarningsHistoryBtn'),
             profileSection: getElement('profile-section'), profileAvatar: getElement('profileAvatarEl'), profileName: getElement('profileNameEl'), profileEmail: getElement('profileEmailEl'), profileTotalMatches: getElement('profileTotalMatchesEl'), profileWonMatches: getElement('profileWonMatchesEl'), profileTotalEarnings: getElement('profileTotalEarningsEl'), logoutProfileBtn: getElement('logoutProfileBtnEl'), policyLinks: querySelAll('.profile-links a[data-policy], .profile-links button[data-policy]'), notificationSwitch: getElement('notificationSwitchEl'),
             // Modals
             policyModalTitle: getElement('policyModalTitleEl'), policyModalBody: getElement('policyModalBodyEl'),
             addAmountForm: getElement('addAmountForm'), addAmountInput: getElement('addAmountInputEl'), addAmountStatusMessage: getElement('addAmountStatusMessageEl'), proceedToPayBtn: getElement('proceedToPayBtnEl'), minDepositAmount: getElement('minDepositAmountEl'),
             withdrawModalBalance: getElement('withdrawModalBalanceEl'), withdrawAmountInput: getElement('withdrawAmountInputEl'), withdrawMethodInput: getElement('withdrawMethodInputEl'), minWithdrawAmount: getElement('minWithdrawAmountEl'), withdrawStatusMessage: getElement('withdrawStatusMessageEl'), submitWithdrawRequestBtn: getElement('submitWithdrawRequestBtnEl'),
             matchDetailsModalTitle: getElement('matchDetailsModalTitleEl'), matchDetailsModalBody: getElement('matchDetailsModalBodyEl'),
             roomIdDisplay: getElement('roomIdDisplayEl'), roomPasswordDisplay: getElement('roomPasswordDisplayEl'),
             securityWarning: getElement('securityWarning')
        };
    }

    /**
     * Initializes the application, Firebase services, and event listeners.
     */
    async init() {
        try {
            this.app = initializeApp(this.firebaseConfig);
            this.db = getDatabase(this.app);
            this.auth = getAuth(this.app);
            console.log("Firebase Initialized Successfully.");
        } catch (error) {
            console.error("Firebase initialization failed:", error);
            document.body.innerHTML = `<div class="alert alert-danger m-5"><strong>Critical Error:</strong> Could not connect to Firebase. Check configuration and console.</div>`;
            return;
        }

        this.showLoader(true);
        await this.loadAppSettings();
        this.initializeEventListeners();
        this.updateGlobalUI(false);
        onAuthStateChanged(this.auth, this.handleAuthStateChange.bind(this));
    }
    
    // --- UTILITY & HELPER FUNCTIONS ---

    showLoader(show) {
        if (this.elements.globalLoader) this.elements.globalLoader.style.display = show ? 'flex' : 'none';
    }

    showStatusMessage(element, message, type = 'danger', autohide = 5000) {
        if (!element) return;
        element.innerHTML = message;
        element.className = `alert alert-${type} mt-3`;
        element.style.display = 'block';
        element.setAttribute('role', 'alert');
        if (autohide) {
            setTimeout(() => {
                if (element.innerHTML === message) element.style.display = 'none';
            }, autohide);
        }
    }

    clearStatusMessage(element) {
        if (!element) return;
        element.style.display = 'none';
        element.innerHTML = '';
        element.removeAttribute('role');
    }

    /**
     * Gets or creates a Bootstrap component instance for an element.
     * @param {HTMLElement} element The DOM element.
     * @param {'Modal'|'Offcanvas'|'Dropdown'} componentType The type of Bootstrap component.
     */
    getBootstrapInstance(element, componentType = 'Modal') {
        if (!element) return null;
        const instanceKey = `${componentType}-${element.id}`;
        if (!this.bootstrapInstances[instanceKey]) {
            try {
                // FIX: Cast window to any to access bootstrap property which may not be on the default window type.
                this.bootstrapInstances[instanceKey] = new (/** @type {any} */ (window)).bootstrap[componentType](element);
            } catch (e) {
                console.error(`Error creating Bootstrap ${componentType} instance for #${element.id}:`, e);
                return null;
            }
        }
        return this.bootstrapInstances[instanceKey];
    }
    
    // --- APPLICATION LOGIC & DATA FETCHING ---

    async loadAppSettings() {
        console.log("Loading App Settings...");
        if (!this.db) return;
        try {
            const snapshot = await get(ref(this.db, 'settings'));
            if (snapshot.exists()) {
                this.state.appSettings = snapshot.val() || {};
                console.log("App Settings Loaded:", this.state.appSettings);
            } else {
                console.warn("App Settings not found in database! Using defaults.");
                this.state.appSettings = {};
            }
        } catch (e) {
            console.error("Settings load failed", e);
            this.state.appSettings = {};
        } finally {
            this.applyAppSettings();
        }
    }
    
    applyAppSettings() {
        const settings = this.state.appSettings;
        if (settings.appName) document.title = settings.appName;
        if (this.elements.appLogo && settings.logoUrl) this.elements.appLogo.src = settings.logoUrl;
        if (this.elements.minWithdrawAmount) this.elements.minWithdrawAmount.textContent = settings.minWithdraw || 50;
        if (this.elements.minDepositAmount) this.elements.minDepositAmount.textContent = settings.minDeposit || 10;
        if (this.elements.addAmountInput) this.elements.addAmountInput.min = settings.minDeposit || 10;
        
        // Initialize Cashfree SDK
        // FIX: Cast window to any to access cashfree property.
        if ((/** @type {any} */ (window)).cashfree) {
             this.state.cashfree = new (/** @type {any} */ (window)).cashfree.Cashfree({
                mode: settings.cashfreeMode === 'production' ? "production" : "sandbox"
             });
             console.log(`Cashfree SDK initialized in ${this.state.cashfree.getMode()} mode.`);
        } else {
             console.error("Cashfree SDK script not loaded!");
        }
    }

    // ... All other methods from the original script will be refactored into this class
    // For brevity, I will show the refactored structure and key new/changed methods.

    // --- AUTHENTICATION ---

    async handleAuthStateChange(user) {
        this.showLoader(true);
        this.detachAllDbListeners();
        this.state.currentUser = user;
        const localReferrerUid = this.state.validReferrerUid;
        this.state.validReferrerUid = null;

        if (user) {
            console.log("Auth State: Logged In", user.uid);
            const userRef = ref(this.db, 'users/' + user.uid);
            try {
                const snapshot = await get(userRef);
                if (snapshot.exists()) {
                    this.state.userProfile = snapshot.val();
                    // Sync profile with Auth data if needed
                    const updates = {};
                    // FIX: Use optional chaining to safely access properties on userProfile which might be an empty object.
                    if (user.displayName && (!this.state.userProfile?.displayName || this.state.userProfile?.displayName !== user.displayName)) updates.displayName = user.displayName;
                    if (user.email && !this.state.userProfile?.email) updates.email = user.email;
                    if (Object.keys(updates).length > 0) {
                        await update(userRef, updates);
                        this.state.userProfile = { ...this.state.userProfile, ...updates };
                    }
                } else {
                    await this.createNewUserProfile(user, localReferrerUid);
                }
                this.populateUserInfo(user, this.state.userProfile);
                this.setupRealtimeListeners(user.uid);
                this.updateGlobalUI(true);
                const targetSection = (this.state.currentSectionId === 'login-section' || !document.getElementById(this.state.currentSectionId)) ? 'home-section' : this.state.currentSectionId;
                this.showSection(targetSection);
            } catch (error) {
                console.error("Profile handling error:", error);
                alert("Error loading profile. Logging out. " + error.message);
                await this.logoutUser();
            }
        } else {
            console.log("Auth State: Logged Out");
            this.state.currentUser = null;
            this.state.userProfile = {};
            this.updateGlobalUI(false);
            this.showSection('login-section');
        }
